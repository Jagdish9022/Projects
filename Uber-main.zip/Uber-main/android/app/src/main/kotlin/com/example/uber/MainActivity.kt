package com.example.uber

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
